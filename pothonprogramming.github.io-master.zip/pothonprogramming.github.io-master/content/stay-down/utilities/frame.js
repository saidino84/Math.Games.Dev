STAY_DOWN.utilities.Frame = {
  
  create(x, y, width, height, offset_x = 0, offset_y = 0) {
    
    return { x, y, width, height, offset_x, offset_y };

  }

};