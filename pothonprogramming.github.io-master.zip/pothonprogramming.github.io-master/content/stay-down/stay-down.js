const STAY_DOWN = (() => ({

  buffers:{},
  images:{},
  initializers:{},
  states:{},
  tools:{},
  utilities:{}

}))();