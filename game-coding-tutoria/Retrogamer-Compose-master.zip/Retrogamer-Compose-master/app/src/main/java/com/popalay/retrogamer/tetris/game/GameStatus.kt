package com.popalay.retrogamer.tetris.game

enum class GameStatus {
    InProgress, Pause, GameOver
}