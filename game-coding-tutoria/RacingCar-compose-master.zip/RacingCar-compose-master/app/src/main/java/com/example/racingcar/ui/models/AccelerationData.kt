package com.example.racingcar.ui.models

data class AccelerationData(val x: Float, val y: Float, val z: Float)
