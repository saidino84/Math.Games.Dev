package com.example.racingcar.ui.models

enum class MovementInput {
    SwipeGestures,
    TapGestures,
    Accelerometer
}