package com.example.racingcar.ui.models

enum class SwipeDirection {
    Right, Left
}