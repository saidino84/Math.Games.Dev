package com.example.racingcar.ui.models

interface RacingResourcePack {
    val backgroundImageDrawable: Int
    val carImageDrawable: Int
    val blockerImageDrawable: Int
}