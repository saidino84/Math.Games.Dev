package com.example.racingcar.ui.models

enum class RotationDirection {
    Right, Left
}