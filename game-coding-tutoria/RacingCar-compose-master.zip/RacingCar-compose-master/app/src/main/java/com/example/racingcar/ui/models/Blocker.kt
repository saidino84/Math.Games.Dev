package com.example.racingcar.ui.models

data class Blocker(val id: Long, val lanePosition: Int)