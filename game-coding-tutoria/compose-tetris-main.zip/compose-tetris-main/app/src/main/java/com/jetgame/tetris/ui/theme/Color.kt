package com.jetgame.tetris.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)


val BrickSpirit = Color(0xDD000000)
val BrickMatrix = Color(0x1F000000)
val BrickHighlight = Color(0xFF560000)
val ScreenBackground = Color(0xff9ead86)


val BodyColor = Color(0xffefcc19)